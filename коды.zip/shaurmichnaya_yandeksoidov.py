import subprocess
subprocess.run('python q1.py', shell=True, check=False)
subprocess.run('python q2.py', shell=True, check=False)
subprocess.run('python q3.py', shell=True, check=False)
subprocess.run('python red.py', shell=True, check=False)



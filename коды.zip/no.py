import pygame
import sys


def text(screen, message1, message2, message3,font_size=None, color=None):
    font = pygame.font.Font("east-sea-dokdo.otf", font_size)
    text_surface = font.render(message1, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (400, 310)
    screen.blit(text_surface, text_rect)
    text_surface = font.render(message2, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (400, 355)
    screen.blit(text_surface, text_rect)
    text_surface = font.render(message3, True, color)
    text_rect = text_surface.get_rect()
    text_rect.center = (400, 400)
    screen.blit(text_surface, text_rect)


def main():
    pygame.init()
    fps = 60
    size = width, height = 800, 800
    screen = pygame.display.set_mode(size)
    clock = pygame.time.Clock()
    running = True
    background = pygame.image.load('проигрыш.jpg').convert()
    gameDisplay = pygame.display.set_mode(size)
    background = pygame.transform.smoothscale(background, gameDisplay.get_size())
    pygame.mixer.init()
    pygame.mixer.music.load("qqq.mp3")
    pygame.mixer.music.play(-1)
    while running:
        gameDisplay.blit(background, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        text(gameDisplay, "ВЫ НЕ СПРАВИЛИСЬ", "И", "ШАУРМУ СЪЕЛ СЕМЁН",
             font_size=40, color=(60, 0, 20))

        pygame.display.flip()
        clock.tick(fps)

    pygame.quit()


if __name__ == "__main__":
    sys.exit(main())
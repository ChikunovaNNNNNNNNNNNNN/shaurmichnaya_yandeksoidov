import pygame
import os
import subprocess

pygame.init()
pygame.display.set_caption('Выбор уровня')
size = width, height = 800, 800
screen = pygame.display.set_mode(size)
icon = pygame.image.load("аб.png")
pygame.display.set_icon(icon)


def load_image(name, colorkey=None):
    fullname = os.path.join(name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Red(pygame.sprite.Sprite):
    image1 = load_image("level one.png")
    image = pygame.transform.scale(image1, (250, 250))

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Red.image
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 130

    def position(self, pos):
        if pos[0] > 100 and pos[0] < 350 and pos[1] > 130 and pos[1] < 380:
            pygame.quit()
            subprocess.run(f'python level1.py', shell=True, check=False)


class Green(pygame.sprite.Sprite):
    image1 = load_image("level two.png")
    image = pygame.transform.scale(image1, (250, 250))

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Green.image
        self.rect = self.image.get_rect()
        self.rect.x = 450
        self.rect.y = 130

    def position(self, pos):
        if pos[0] > 450 and pos[0] < 600 and pos[1] > 130 and pos[1] < 380:
            pygame.quit()
            subprocess.run(f'python level2.py', shell=True, check=False)


class Blue(pygame.sprite.Sprite):
    image1 = load_image("level three.png")
    image = pygame.transform.scale(image1, (250, 250))

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Blue.image
        self.rect = self.image.get_rect()
        self.rect.x = 280
        self.rect.y = 480

    def position(self, pos):
        if pos[0] > 280 and pos[0] < 350 + 250 and pos[1] > 480 and pos[1] < 480 + 250:
            pygame.quit()
            subprocess.run(f'python level3.py', shell=True, check=False)


if __name__ == '__main__':
    all_sprites = pygame.sprite.Group()
    red = Red(all_sprites)
    green = Green(all_sprites)
    blue = Blue(all_sprites)

    running = True
    fps = 60
    clock = pygame.time.Clock()
    background = pygame.image.load('фон 0.jpg').convert()
    gameDisplay = pygame.display.set_mode(size)
    background = pygame.transform.smoothscale(background, gameDisplay.get_size())
    pygame.mixer.music.load("qqq.mp3")
    pygame.mixer.music.play(-1)
    while running:
        gameDisplay.blit(background, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                red.position(event.pos)
                green.position(event.pos)
                blue.position(event.pos)
        all_sprites.draw(screen)
        clock.tick(fps)
        pygame.display.flip()
    pygame.quit()
